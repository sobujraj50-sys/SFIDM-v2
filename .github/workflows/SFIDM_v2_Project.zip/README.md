# SFIDM - Version 2 (Smart Video & File Download Manager)

## What's New in Version 2
- **YouTube, Facebook, TikTok, Instagram, X, Reddit & 1,000+ Sites** powered by built-in `yt-dlp` + `FFmpeg`
- **Quality & Format Selector:** Best MP4, 1080p HD, 720p HD, 480p SD, and Audio Only (MP3)
- **Built-In Browser & Smart Video Sniffer:** Browse any website and automatically detect `.mp4`, `.m3u8` (HLS), `.mp3`, `.pdf`, `.zip`, `.apk` files
- **1-Tap Engine Update:** Update `yt-dlp` directly inside the app whenever YouTube/Facebook changes
- **Multi-Thread HTTP Downloader (4x / 8x / 16x)** for direct file downloads
- **Bilingual UI (বাংলা & English)** + **6 Dark Themes**
